
  # Formulario Registro Deportista

  This is a code bundle for Formulario Registro Deportista. The original project is available at https://www.figma.com/design/GOE93bAmVoHug3GXHBMzYO/Formulario-Registro-Deportista.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  